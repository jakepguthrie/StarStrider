#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#include <SDL.h>
#include <SDL_ttf.h>
#include <math.h>
#include <time.h>

#define FPSRATE 60
#define SCREENW 800
#define SCREENH 600

/* TODO: Score- every full line + 100 pts * speed, every insta +10*speed, every GameBlockDown from key +1*speed */
/* TODO: Notification of bonuses*/
/* TODO: insta- GameBlock instantly falls down, minimal vertical distance is 5 tiles*/
/* TODO: table of highest scores*/
/* TODO: Redesign main menu buttons */


int frame=0;
TTF_Font *font=NULL;
SDL_Color textColor = {0,0,0};
SDL_Surface *ticks=NULL;
SDL_Surface *frames=NULL;
SDL_Surface *fps=NULL;
SDL_Surface *screen=NULL;

int gamestatus=0; // 0- menu 1- game 2-pause 3-level choice 4- game over screen 5-help screen


char fpschar[10];

void RBC_Write(int x, int y, int number, SDL_Surface *dest);
void RBC_Write(int x, int y, const char *text, SDL_Surface *dest);
void RBC_DrawRect(int x, int y, int w, int h, int r, int b, int g);
class CGameManager;

class CTile{
	private:

	int x;
	int y;

	public:
	CTile(void){
			x=250;
			y=0;
	}

	void  Set(int xx, int yy){
	x=xx;y=yy;
	}

	void Draw(int x, int y, int kind){
			SDL_Rect offset;
			offset.x=x;
			offset.y=y;
			offset.w=30;
			offset.h=30;
			//SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, 120,144,72));
			SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, 0,0,0));

			offset.x=x+1;
			offset.y=y+1;
			offset.w=28;
			offset.h=28;

			SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, 120,144,72));
			for(int i=0; i<30; i++){
					RBC_DrawRect(x+i, y+i, 1, 1, 0, 0, 0);
					RBC_DrawRect(x+i, y+(30-i), 1, 1, 0, 0, 0);
			}
	}

	void Draw(int x, int y, int r, int g, int b){
			SDL_Rect offset;
			offset.x=x;
			offset.y=y;
			offset.w=30;
			offset.h=30;
			SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, 0, 0, 0));

			offset.x=x+1;
			offset.y=y+1;
			offset.w=28;
			offset.h=28;
			SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, r, g, b));
	}

	int GetX(void){return x;}
	int GetY(void){return y;}

};

class CBlock{
	private:
		int CBlockColor[3];
		int r, g, b;
		CTile tile;
		bool lock;
		bool tiletable[4][4]; //tiletable[1][1] is the one we turn by
		bool bufftiletable[4][4];

	friend class CGameManager;
	public:
	CBlock(int l, int ax, int ay, int bx, int by, int cx, int cy, int dx, int dy, int rr, int gg, int bb){
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				tiletable[i][j]=0;
				}
			}
		lock=l;
		tiletable[ax+1][ay+1]=1;
		tiletable[bx+1][by+1]=1;
		tiletable[cx+1][cy+1]=1;
		tiletable[dx+1][dy+1]=1;
		r=rr;g=gg;b=bb;
	}

	void Set(int l, int ax, int ay, int bx, int by, int cx, int cy, int dx, int dy, int rr, int gg, int bb){
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				tiletable[i][j]=0;
				}
			}
		lock=l;
		tiletable[ax+1][ay+1]=1;
		tiletable[bx+1][by+1]=1;
		tiletable[cx+1][cy+1]=1;
		tiletable[dx+1][dy+1]=1;
		r=rr;g=gg;b=bb;
	}

	void Draw(int x, int y){
		SDL_Rect offset;
		offset.w=30;
		offset.h=30;

		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(tiletable[i][j]){
						offset.x=x+250+(30*(i));
						offset.y=y+(30*(j));
						tile.Draw(x+250+(30*i), y+30*j, r, g, b);
				}
			}}

	}

	void TryTurn(void){
		for(int i=0; i<4; i++){for(int j=0; j<4; j++){bufftiletable[i][j]=0;}}
		bufftiletable[1][1]=1;
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(tiletable[i][j]){
					if(i-1<0 && j-1<0){
					 bufftiletable[0][2]=1;
					}else
					if(i-1<0 && j-1>0){
					 bufftiletable[i+2][j]=1;
					}else
					if(i-1>0 && j-1>0){
					 bufftiletable[i][j-2]=1;
					}else
					if(i-1>0 && j-1<0){
					 bufftiletable[i-2][j]=1;
					}else
					if(i==0 && j==1){bufftiletable[1][2]=1;}else
					if(i==1 && j==2){bufftiletable[2][1]=1;}else
					if(i==2 && j==1){bufftiletable[1][0]=1;}else
					if(i==1 && j==0){bufftiletable[0][1]=1;}else
					if(i==3 && j==1){bufftiletable[1][3]=1;}else
					if(i==1 && j==3){bufftiletable[3][1]=1;}
				}
			}
		}
	}

	void Turn(void){
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
			tiletable[i][j]=bufftiletable[i][j];
			}
		}

	}

	bool GetTable(void){
		return tiletable;
	}

};

class CButton{
		private:
		bool active;
		int ir, ig, ib;
		int ar, ag, ab;
		int x, y;
		int w,h;
		const char* text;

		public:
		CButton(int xx, int yy, int width, int height, int ired, int igreen, int iblue, int ared, int agreen, int ablue, int aactive, const char *label){
			x=xx;y=yy;
			w=width;h=height;
			ir=ired;ig=igreen;ib=iblue;
			ar=ared;ag=agreen;ab=ablue;
			text=label;
			active=aactive;
		}

		bool Active(void){
			return active;
			}

		void ChangeActivity(void){
				active=!active;
		}

		void Draw(void){
			if(active){
				RBC_DrawRect(x-1, y-1, w+2, h+2, 255, 255, 255);
				RBC_DrawRect(x, y, w, h, ar, ag, ab);
			}else{
				RBC_DrawRect(x, y, w, h, ir, ig, ib);
				}
			RBC_Write(x+10, y+h/4, text, screen);
		}
};

SDL_Surface* RBC_LoadBMP(const char* name){
	SDL_Surface* loadedimg=SDL_LoadBMP(name);
	return SDL_DisplayFormat(loadedimg);
}

void RBC_BlitSurface(int x, int y, SDL_Surface *src, SDL_Surface *dest){
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;

	SDL_BlitSurface(src, NULL, dest, &offset);
}/*Method of loading bitmap with easy calling*/

void RBC_Write(int x, int y, const char* text, SDL_Surface *dest){
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;
	SDL_Surface *buff=TTF_RenderText_Solid(font, text, textColor);
	SDL_BlitSurface(buff, NULL, dest, &offset);
	SDL_FreeSurface(buff);
}/*Method of writing text in const char format on the screen. It uses global font*/

void RBC_Write(int x, int y, int number, SDL_Surface *dest){
	char textbuffer[100];
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;
	SDL_Surface *buff=TTF_RenderText_Solid(font, itoa(number, textbuffer, 10), textColor);
	SDL_BlitSurface(buff, NULL, dest, &offset);
	SDL_FreeSurface(buff);
}/*Overloaded version of function for writing numbers on the screen*/

void RBC_DrawRect(int x, int y, int w, int h, int r, int g, int b){
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;
	offset.w=w;
	offset.h=h;
	SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, r, g, b));
}

int FPSStart=0;
int FPSFinish=0;
int LastSec=0;
int LastFPS=FPSRATE;
int LastFrame;

int GetFPS(void){
	if((SDL_GetTicks()/1000)-LastSec){
		LastSec=SDL_GetTicks()/1000;
		LastFPS=FPSFinish-FPSStart;
		FPSStart=frame;
	}else{
		FPSFinish=frame;
	}
	return LastFPS;
}/*A method which shows frames count in last second.*/

void SetFPS(void){
	if(SDL_GetTicks()-LastFrame<=(1000/FPSRATE)){SDL_Delay((1000/FPSRATE)-(SDL_GetTicks()-LastFrame));}
}/*Function which locks frames per second according to FPSRATE definition*/

class CGameManager{
	private:
	int speed;
	int done;
	int score;
	int level;
	int LastAction;
	bool warning;
	CTile* GameTable[10][20];

	bool blocktable;

	int gameblockx;
	int gameblocky;

	public:

	CGameManager(void){
			for(int i=0, j=0; i<10; i++){for(j=0;j<20;j++){GameTable[i][j]=NULL;}}

			//for(int i=0; i<10; i++){
			//GameTable[8][i]=new CTile;
			//GameTable[8][i]->Set(250+30*8, 30*i);}
			done=0;
			LastAction=0;
			score=0;
			speed=2;
			gameblockx=2;
			gameblocky=0;
	}

	int ReturnSpeed(void){return speed;}
	int ReturnDone(void){return done;}
	int ReturnScore(void){return score;}

	void ClearGame(void){
			for(int i=0; i<10; i++){
				for(int j=0; j<20;j++){
						GameTable[i][j]=NULL;
				}
			}
			score=0;
			done=0;
	}

	void SetLevel(int value){
			level=value;
			if(value==1){speed=2;}
			else if(value==2){speed=6;}
			else if(value==3){speed=10;}
	}

	void AddToScore(int value, int multipier){
		score+=value*multipier*(speed/2)*level;
	}

	void MoveBlockLeft(CBlock* block){
			bool collision=0;

			for(int i=3; i>=0 && !collision; i--){
				for(int j=0; j<4 && !collision; j++){
					if(block->tiletable[i][j]){
							if(GameTable[i+gameblockx-1][j+gameblocky]){collision=1;}
					}
				}
			}

			if(gameblockx<=0){
			for(int i=0; i<4; i++){
					if(block->tiletable[0-gameblockx][i]){collision=1;}
			}
			}
			if(!collision){--gameblockx;warning=0;}
	}

	/*void Insta(CBlock* block){
			int lowest=-1;
			for(int i=0, j=3; i<4; i++){
				for(j=3; j>=0; j--){
					if(block->tiletable[i][j]){lowest=i;}
				}
	}*/

	void MoveBlockRight(CBlock* block){
			bool collision=0;

			for(int i=3; i>=0 && !collision; i--){
				for(int j=0; j<4 && !collision; j++){
					if(block->tiletable[i][j]){
							if(GameTable[i+gameblockx+1][j+gameblocky]){collision=1;}
					}
				}
			}

			if(gameblockx>=6){
			for(int i=0; i<4; i++){
					if(block->tiletable[10-gameblockx-1][i]){collision=1;}
			}
			}
			if(!collision){++gameblockx;warning=0;}
	}

	int GetGameBlockX(void){
			return gameblockx;
	}

	int GetGameBlockY(void){
			return gameblocky;
	}

	void SpeedUp(void){speed=speed+2;}

	void TurnGameBlock(CBlock* block){
		block->TryTurn();
		bool collision=0;

		if(gameblockx>6){ //from right
			for(int i=0; i<4; i++){
					if(block->bufftiletable[10-gameblockx][i]){collision=1;}
			}
		}

		if(gameblockx<0){ //from left
			for(int i=0; i<4; i++){
					if(block->bufftiletable[-gameblockx][i]){collision=1;}
			}
		}

		if(gameblocky>15){ /*it is case when table of block reaches the end of the board*/
			for(int i=0; i<4; i++){
					if(block->bufftiletable[i][20-gameblocky]){collision=1;}
			}
			}

		for(int i=0; i<4 && !collision; i++){
			for(int j=0; j<4 && !collision; j++){
				if(block->bufftiletable[i][j]){
					if(GameTable[i+gameblockx][j+gameblocky]){
						collision=1;
					}
				}
			}
		}

		if(!collision){block->Turn();warning=0;}
	}

	void PurgeVerse(int number){

			for(int i=number-1; i>0; i--){
					for(int j=0; j<10; j++){
						//if(GameTable[j][i]==NULL){GameTable[j][i+1]=NULL;}else{
						GameTable[j][i+1]=GameTable[j][i];//}
					}
			}
	}

	void CheckTable(void){
		int lines=0;
		int counter=0;
		for(int i=19, j; i>=0 && counter!=11; i--){
			counter=0;
			for(j=0; j<10; j++){
				if(GameTable[j][i]){counter++;}
			}
			if(counter==10){PurgeVerse(i);i++;done++;lines++;}
			else if(!counter){counter=11;}
		}
		switch(lines){
				case 1:AddToScore(1,100);break;
				case 2:AddToScore(2,150);break;
				case 3:AddToScore(3,200);break;
				case 4:AddToScore(4,400);break;
		}
	}

	bool MoveBlockDown(CBlock* block, bool fromkey){
			bool collision=0;

			/*Hypothetical collision with other tile*/
			for(int i=0; i<4 && !collision; i++){
				for(int j=3; j>=0 && !collision; j--){
					if(block->tiletable[i][j]){
							if(GameTable[i+gameblockx][j+gameblocky+1]){collision=1;}
					}
				}
			}


			if(gameblocky>15){ /*it is case when table of block reaches the end of the board*/
			for(int i=0; i<4; i++){
					if(block->tiletable[i][19-gameblocky]){collision=1;}
			}
			}
			if(!collision){++gameblocky;if(fromkey){AddToScore(1, 1);}}else{warning=1;}
			return collision;
	}

	void Refresh(CBlock* block, CBlock* next){
		int tiem=SDL_GetTicks();
		if(!(done%15) && done!=0){SpeedUp();done++;}
		if(tiem-LastAction>1000/speed){
			if(!warning){
			LastAction=tiem;
			MoveBlockDown(block, 0);
		//block->tiletable[0][0]
			}else{
				for(int i=0; i<4; i++){
					for(int j=0; j<4; j++){
						if(block->tiletable[i][j]){
							GameTable[i+gameblockx][j+gameblocky]=new CTile;
							GameTable[i+gameblockx][j+gameblocky]->Set(250+30*(i+gameblockx), 30*(j+gameblocky));
						}
					}
				}
			gameblockx=3;
			gameblocky=-1;


			*block=*next;
			if(MoveBlockDown(block, 0)){gamestatus=4;}
			srand(time(NULL));
			switch(rand()%7){
					case 0: next->Set(0, -1, 0, 0, 0, 1, 0, 0, -1,179,206,221);break; //t
					case 1: next->Set(0, -1,-1,0,-1,0,0,1,0, 198,255,126);break; //z
					case 2: next->Set(0, -1,0,0,0,0,-1,1,-1, 126,196,255);break; //s
					case 3: next->Set(1, 0,0,1,0,0,1,1,1, 100, 100, 0);break; //o
					case 4: next->Set(0, 0,-1,0,0,0,1,0,2, 255,159,126);break; //i
					case 5: next->Set(0, -1,1,0,1,0,0,0,-1, 139,77,156);break; //j
					case 6: next->Set(0, 0,-1,0,0,0,1,1,1, 255,229,126);break; //l
			}

			warning=0;

			CheckTable();
			}
		}
	}

	void DrawTable(void){
			for(int i=0; i<10; i++){
				for(int j=0; j<20; j++){
					if(GameTable[i][j]!=NULL){
						//GameTable[i][j]->Set(250+i*30, j*30);
						GameTable[i][j]->Draw(250+i*30, j*30, 0);
						}
				}
			}
	}
};

int main ( int argc, char** argv )
{

    if ( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "Unable to init SDL: %s\n", SDL_GetError() );
        return 1;
    }

     atexit(SDL_Quit);

     screen = SDL_SetVideoMode(SCREENW, SCREENH, 32,
                                           SDL_HWSURFACE|SDL_DOUBLEBUF);
    if ( !screen )
    {
        printf("Unable to set 800x600 video: %s\n", SDL_GetError());
        return 1;
    }
	SDL_WM_SetCaption("Szit the Game", NULL);
	if( TTF_Init() == -1 )
    {
		printf("Unable to initialize font");
        return 1;
    }

    font=TTF_OpenFont("tahoma.ttf", 28);
    if(font){printf("Success");}

    // centre the bitmap on screen

	CGameManager manager;

    bool done = false;
    CBlock blockT(0, -1, 0, 0, 0, 1, 0, 0, -1, 100, 100, 100); //t
    blockT.TryTurn();
    blockT.Turn();
    blockT.TryTurn();
    blockT.Turn();

    CBlock blockZ(0, -1,-1,0,-1,0,0,1,0, 198,255,126); //z
    CBlock blockS(0, -1,0,0,0,0,-1,1,-1, 126,196,255); //s
    CBlock blockO(1, 0,0,1,0,0,1,1,1, 100, 100, 0); //o
    CBlock blockI(0, 0,-1,0,0,0,1,0,2, 255,159,126); //i
    CBlock blockJ(0, -1,1,0,1,0,0,0,-1, 139,77,156); //j
    CBlock blockL(0, 0,-1,0,0,0,1,1,1, 255,229,126); //l

    CBlock GameBlock(0, -1, 0, 0, 0, 1, 0, 0, -1, 179,206,221); //creating t
    CBlock NextBlock(0, -1, 0, 0, 0, 1, 0, 0, -1, 179,206,221); //t
    //CBlock GameBlock(0, -1,0,0,0,0,-1,1,-1); //s
    //CBlock GameBlock(0, 0,-1,0,0,0,1,0,2); //i


	CButton start(300, 350, 200, 50, 100, 100, 100, 150, 150, 150, 1, "Start");
	CButton help(300, 425, 200, 50, 100, 100, 100, 150, 150, 150, 0, "Help");
	CButton exit(300, 500, 200, 50, 100, 100, 100, 150, 150, 150, 0, "Exit");
	CButton easy(100, 350, 200, 50, 200, 200, 200, 255, 255, 255, 0, "Easy");
	CButton medium(300, 350, 200, 50, 200, 200, 200, 255, 255, 255, 1, "Medium");
	CButton hard(500, 350, 200, 50, 200, 200, 200, 255, 255, 255, 0, "Hard");
	manager.Refresh(&GameBlock, &NextBlock);
	manager.Refresh(&GameBlock, &NextBlock);


	srand(time(NULL));
			switch(rand()%7){
					case 0: GameBlock.Set(0, -1, 0, 0, 0, 1, 0, 0, -1,179,206,221);break; //t
					case 1: GameBlock.Set(0, -1,-1,0,-1,0,0,1,0, 198,255,126);break; //z
					case 2: GameBlock.Set(0, -1,0,0,0,0,-1,1,-1, 126,196,255);break; //s
					case 3: GameBlock.Set(1, 0,0,1,0,0,1,1,1, 100, 100, 0);break; //o
					case 4: GameBlock.Set(0, 0,-1,0,0,0,1,0,2, 255,159,126);break; //i
					case 5: GameBlock.Set(0, -1,1,0,1,0,0,0,-1, 139,77,156);break; //j
					case 6: GameBlock.Set(0, 0,-1,0,0,0,1,1,1, 255,229,126);break; //l
			}

	srand(time(NULL)+SDL_GetTicks());
			switch(rand()%7){
					case 0: NextBlock.Set(0, -1, 0, 0, 0, 1, 0, 0, -1,179,206,221);break; //t
					case 1: NextBlock.Set(0, -1,-1,0,-1,0,0,1,0, 198,255,126);break; //z
					case 2: NextBlock.Set(0, -1,0,0,0,0,-1,1,-1, 126,196,255);break; //s
					case 3: NextBlock.Set(1, 0,0,1,0,0,1,1,1, 100, 100, 0);break; //o
					case 4: NextBlock.Set(0, 0,-1,0,0,0,1,0,2, 255,159,126);break; //i
					case 5: NextBlock.Set(0, -1,1,0,1,0,0,0,-1, 139,77,156);break; //j
					case 6: NextBlock.Set(0, 0,-1,0,0,0,1,1,1, 255,229,126);break; //l
			}

    // program main loop
    while (!done)
    {
        // message processing loop
        SDL_Event event;
        ++frame;
		SetFPS();
		LastFrame=SDL_GetTicks();

		if(gamestatus==1){manager.Refresh(&GameBlock, &NextBlock);
		}

        while (SDL_PollEvent(&event))
        {
            // check for messages
            switch (event.type)
            {
                // exit if the window is closed
            case SDL_QUIT:
                done = true;
                break;

                // check for keypresses
            case SDL_KEYDOWN:
                {
                    // exit if ESCAPE is pressed
                    if (event.key.keysym.sym == SDLK_ESCAPE)
                        {done = true;}

					if(!gamestatus)
					{
						if(event.key.keysym.sym == SDLK_DOWN){
							if(start.Active()){start.ChangeActivity(); help.ChangeActivity();}else
							if(help.Active()){help.ChangeActivity(); exit.ChangeActivity();}else
							if(exit.Active()){exit.ChangeActivity(); start.ChangeActivity();}
							}
						else if(event.key.keysym.sym == SDLK_UP){
							if(start.Active()){start.ChangeActivity(); exit.ChangeActivity();}else
							if(help.Active()){help.ChangeActivity(); start.ChangeActivity();}else
							if(exit.Active()){exit.ChangeActivity(); help.ChangeActivity();}
						}
						if(event.key.keysym.sym == SDLK_RETURN){
							if(start.Active()){gamestatus=3;}
							else if(help.Active()){gamestatus=5;}
							else if(exit.Active()){done=1;}
						}
					}else
					if(gamestatus==1){
						if(event.key.keysym.sym == SDLK_DOWN){
								manager.MoveBlockDown(&GameBlock, 1);
						}
						if(event.key.keysym.sym == SDLK_SPACE){
								manager.TurnGameBlock(&GameBlock);
						}
						if(event.key.keysym.sym == SDLK_LEFT){
								manager.MoveBlockLeft(&GameBlock);
						}
						if(event.key.keysym.sym == SDLK_RIGHT){
								manager.MoveBlockRight(&GameBlock);
						}
						if(event.key.keysym.sym == SDLK_w){
								manager.SpeedUp();
						}
						if(event.key.keysym.sym ==SDLK_p){
							gamestatus=2;
						}
					}else
					if(gamestatus==2){
						if(event.key.keysym.sym ==SDLK_p){
							gamestatus=1;
						}
					}else
					if(gamestatus==3){
						if(event.key.keysym.sym == SDLK_RETURN){
							if(easy.Active()){manager.SetLevel(1);}else
							if(medium.Active()){manager.SetLevel(2);}else
							if(hard.Active()){manager.SetLevel(3);}
							gamestatus=1;
						}else
						if(event.key.keysym.sym == SDLK_RIGHT){
							if(easy.Active()){easy.ChangeActivity(); medium.ChangeActivity();}else
							if(medium.Active()){medium.ChangeActivity(); hard.ChangeActivity();}else
							if(hard.Active()){hard.ChangeActivity(); easy.ChangeActivity();}
						}else
						if(event.key.keysym.sym == SDLK_LEFT){
							if(easy.Active()){easy.ChangeActivity(); hard.ChangeActivity();}else
							if(medium.Active()){medium.ChangeActivity(); easy.ChangeActivity();}else
							if(hard.Active()){hard.ChangeActivity(); medium.ChangeActivity();}
						}
					}else
					if(gamestatus==4){
							if(event.key.keysym.sym){
									SDL_Delay(1000);
									gamestatus=0;
									manager.ClearGame();
							}
					}else
					if(gamestatus==5){
							if(event.key.keysym.sym){
									gamestatus=0;
							}
					}
                    break;
                }
            } // end switch
         }// end of message processing

        // DRAWING STARTS HERE


        // clear screen
        SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, 0, 0, 0));

        // draw bitmap




		if(gamestatus==0){
			int a=SDL_GetTicks();

			RBC_DrawRect(0, 0, screen->w, screen->h, 0, 0, 50);

			RBC_DrawRect((0+frame/2)%screen->w, 0, screen->w/5, screen->h, 105,210,231);
			if(((0+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((0+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 105,210,231);}

			RBC_DrawRect((screen->w/5+frame/2)%screen->w, 0, screen->w/5, screen->h, 167,219,216);
			if(((screen->w/5+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 167,219,216);}

			RBC_DrawRect((screen->w/5*2+frame/2)%screen->w, 0, screen->w/5, screen->h, 224,228,204);
			if(((screen->w/5*2+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*2+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 224,228,204);}

			RBC_DrawRect((screen->w/5*3+frame/2)%screen->w, 0, screen->w/5, screen->h, 243,134,48);
			if(((screen->w/5*3+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*3+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 243,134,48);}

			RBC_DrawRect((screen->w/5*4+frame/2)%screen->w, 0, screen->w/5, screen->h, 250,105,0);
			if(((screen->w/5*4+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*4+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 250,105,0);}


			blockS.Draw(-100, 90+sin(a/100)*50);
			blockZ.Draw(50, 90+sin(a/100+10)*50);
			blockI.Draw(200, 90+sin(a/100+20)*50);
			blockT.Draw(350, 90+sin(a/100+30)*50);

			start.Draw();
			help.Draw();
			exit.Draw();

		}else
		if(gamestatus==1){
			switch(manager.ReturnSpeed()){
					case 2:RBC_DrawRect(0, 0, screen->w, screen->h, 105,210,231);break;
					case 4:RBC_DrawRect(0, 0, screen->w, screen->h, 167,219,216);break;
					case 6:RBC_DrawRect(0, 0, screen->w, screen->h, 224,228,204);break;
					case 8:RBC_DrawRect(0, 0, screen->w, screen->h, 243,134,48);break;
					case 10:RBC_DrawRect(0, 0, screen->w, screen->h, 250,105,0);break;
					case 12:RBC_DrawRect(0, 0, screen->w, screen->h, 250,70,0);break;
					case 14:RBC_DrawRect(0, 0, screen->w, screen->h, 250,35,0);break;
					case 16:RBC_DrawRect(0, 0, screen->w, screen->h, 250,10,0);break;
					case 18:RBC_DrawRect(0, 0, screen->w, screen->h, 250,0,0);break;

			}
			RBC_DrawRect(245, 0, 310, 600, 0,0,0);
			RBC_DrawRect(250, 0, 300, 600, 85,98,112);
			RBC_DrawRect(570, 70, 210, 210, 0,0,0);
			RBC_DrawRect(575, 75, 200, 200, 200, 200, 200);
			GameBlock.Draw(manager.GetGameBlockX()*30, manager.GetGameBlockY()*30);
			NextBlock.Draw(375, 150);
			manager.DrawTable();
			RBC_Write(575, 300, "Speed:", screen);
			RBC_Write(675, 300, manager.ReturnSpeed(), screen);
			RBC_Write(575, 330, "Lines:", screen);
			RBC_Write(675, 330, manager.ReturnDone(), screen);
			RBC_Write(575, 360, "Score:", screen);
			RBC_Write(675, 360, manager.ReturnScore(), screen);

		}else
		if(gamestatus==2){
			switch(manager.ReturnSpeed()){
					case 2:RBC_DrawRect(0, 0, screen->w, screen->h, 105,210,231);break;
					case 4:RBC_DrawRect(0, 0, screen->w, screen->h, 167,219,216);break;
					case 6:RBC_DrawRect(0, 0, screen->w, screen->h, 224,228,204);break;
					case 8:RBC_DrawRect(0, 0, screen->w, screen->h, 243,134,48);break;
					case 10:RBC_DrawRect(0, 0, screen->w, screen->h, 250,105,0);break;
					case 12:RBC_DrawRect(0, 0, screen->w, screen->h, 250,70,0);break;
					case 14:RBC_DrawRect(0, 0, screen->w, screen->h, 250,35,0);break;
					case 16:RBC_DrawRect(0, 0, screen->w, screen->h, 250,10,0);break;
					case 18:RBC_DrawRect(0, 0, screen->w, screen->h, 250,0,0);break;

			}
			RBC_DrawRect(245, 0, 310, 600, 0,0,0);
			RBC_DrawRect(250, 0, 300, 600, 85,98,112);
			RBC_Write(360, 250, "Pause", screen);
		}else
		if(gamestatus==3){
			RBC_DrawRect((0+frame/2)%screen->w, 0, screen->w/5, screen->h, 105,210,231);
			if(((0+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((0+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 105,210,231);}

			RBC_DrawRect((screen->w/5+frame/2)%screen->w, 0, screen->w/5, screen->h, 167,219,216);
			if(((screen->w/5+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 167,219,216);}

			RBC_DrawRect((screen->w/5*2+frame/2)%screen->w, 0, screen->w/5, screen->h, 224,228,204);
			if(((screen->w/5*2+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*2+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 224,228,204);}

			RBC_DrawRect((screen->w/5*3+frame/2)%screen->w, 0, screen->w/5, screen->h, 243,134,48);
			if(((screen->w/5*3+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*3+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 243,134,48);}

			RBC_DrawRect((screen->w/5*4+frame/2)%screen->w, 0, screen->w/5, screen->h, 250,105,0);
			if(((screen->w/5*4+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*4+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 250,105,0);}


					easy.Draw();
					medium.Draw();
					hard.Draw();
		}else
		if(gamestatus==4){
			switch(manager.ReturnSpeed()){
					case 2:RBC_DrawRect(0, 0, screen->w, screen->h, 105,210,231);break;
					case 4:RBC_DrawRect(0, 0, screen->w, screen->h, 167,219,216);break;
					case 6:RBC_DrawRect(0, 0, screen->w, screen->h, 224,228,204);break;
					case 8:RBC_DrawRect(0, 0, screen->w, screen->h, 243,134,48);break;
					case 10:RBC_DrawRect(0, 0, screen->w, screen->h, 250,105,0);break;
					case 12:RBC_DrawRect(0, 0, screen->w, screen->h, 250,70,0);break;
					case 14:RBC_DrawRect(0, 0, screen->w, screen->h, 250,35,0);break;
					case 16:RBC_DrawRect(0, 0, screen->w, screen->h, 250,10,0);break;
					case 18:RBC_DrawRect(0, 0, screen->w, screen->h, 250,0,0);break;

			}
			RBC_DrawRect(245, 0, 310, 600, 0,0,0);
			RBC_DrawRect(250, 0, 300, 600, 85,98,112);
			RBC_DrawRect(570, 70, 210, 210, 0,0,0);
			RBC_DrawRect(575, 75, 200, 200, 200, 200, 200);
			GameBlock.Draw(manager.GetGameBlockX()*30, manager.GetGameBlockY()*30);
			NextBlock.Draw(375, 150);
			manager.DrawTable();
			RBC_Write(575, 300, "Speed:", screen);
			RBC_Write(675, 300, manager.ReturnSpeed(), screen);
			RBC_Write(575, 330, "Lines:", screen);
			RBC_Write(675, 330, manager.ReturnDone(), screen);
			RBC_Write(575, 360, "Score:", screen);
			RBC_Write(675, 360, manager.ReturnScore(), screen);

			for(int i=0; i<screen->w/2; i++){
					for(int j=0; j<screen->h/2; j++){
							RBC_DrawRect(i*2, j*2, 1,1, 0,0,0);
					}
			}


				RBC_Write(300, 300, "Game Over", screen);
				RBC_Write(300, 350, manager.ReturnScore(), screen);

		}else
		if(gamestatus==5){
			RBC_DrawRect((0+frame/2)%screen->w, 0, screen->w/5, screen->h, 105,210,231);
			if(((0+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((0+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 105,210,231);}

			RBC_DrawRect((screen->w/5+frame/2)%screen->w, 0, screen->w/5, screen->h, 167,219,216);
			if(((screen->w/5+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 167,219,216);}

			RBC_DrawRect((screen->w/5*2+frame/2)%screen->w, 0, screen->w/5, screen->h, 224,228,204);
			if(((screen->w/5*2+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*2+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 224,228,204);}

			RBC_DrawRect((screen->w/5*3+frame/2)%screen->w, 0, screen->w/5, screen->h, 243,134,48);
			if(((screen->w/5*3+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*3+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 243,134,48);}

			RBC_DrawRect((screen->w/5*4+frame/2)%screen->w, 0, screen->w/5, screen->h, 250,105,0);
			if(((screen->w/5*4+frame/2)%screen->w+screen->w/5)>screen->w){RBC_DrawRect(0, 0, ((screen->w/5*4+frame/2)%screen->w+screen->w/5)-screen->w, screen->h, 250,105,0);}

			RBC_Write(20, 300, "Use left and right arrow to move block sideways", screen);
			RBC_Write(20, 350, "Use down arrow to move block down faster for extra points", screen);
			RBC_Write(20, 400, "Use space to turn falling tetramino", screen);
			RBC_Write(20, 450, "Hit 'P' to pause game", screen);
		}

        RBC_Write(10, 20, "FPS: ", screen);RBC_Write(70, 20, GetFPS(), screen);

        // DRAWING ENDS HERE

        // finally, update the screen :)
        SDL_Flip(screen);
    } // end main loop

    // free loaded bitmap
	TTF_CloseFont(font);
	TTF_Quit();
    // all is well ;)
    printf("Exited cleanly\n");
    return 0;
}
