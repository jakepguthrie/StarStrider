#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#include <SDL.h>
#include <SDL_ttf.h>
#include <math.h>
#include <time.h>

#define FPSRATE 60
#define SCREENW 800
#define SCREENH 600


int frame=0;
TTF_Font *font=NULL;
SDL_Color textColor = { 255, 0, 0};
SDL_Surface *ticks=NULL;
SDL_Surface *frames=NULL;
SDL_Surface *fps=NULL;
SDL_Surface *screen=NULL;

int gamestatus=0; // 0- menu 1- game 2-pause


char fpschar[10];

void RBC_Write(int x, int y, int number, SDL_Surface *dest);
void RBC_Write(int x, int y, const char *text, SDL_Surface *dest);
void RBC_DrawRect(int x, int y, int w, int h, int r, int b, int g);
class CGameManager;

class CTile{
	private:

	int x;
	int y;

	public:
	CTile(void){
			x=250;
			y=0;
	}

	void  Set(int xx, int yy){
	x=xx;y=yy;
	}

	void Draw(int x, int y, int kind){
			SDL_Rect offset;
			offset.x=x;
			offset.y=y;
			offset.w=30;
			offset.h=30;
			SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, 20, 20, 80));
			SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, 200, 0, 80));
			for(int i=0; i<15; i++){
					RBC_DrawRect(x+i, y+i, 1, 1, 0, 0, 0);
					RBC_DrawRect(x+(30-i), y+(30-i), 1, 1, 0, 0, 0);
			}
	}

	void Draw(int x, int y, int r, int g, int b){
			SDL_Rect offset;
			offset.x=x;
			offset.y=y;
			offset.w=30;
			offset.h=30;
			SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, r, g, b));
	}

	int GetX(void){return x;}
	int GetY(void){return y;}

};

class CBlock{
	private:
		int CBlockColor[3];
		int r, g, b;
		CTile tile;
		bool lock;
		bool tiletable[4][4]; //tiletable[1][1] is the one we turn by
		bool bufftiletable[4][4];

	friend class CGameManager;
	public:
	CBlock(int l, int ax, int ay, int bx, int by, int cx, int cy, int dx, int dy, int rr, int gg, int bb){
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				tiletable[i][j]=0;
				}
			}
		lock=l;
		tiletable[ax+1][ay+1]=1;
		tiletable[bx+1][by+1]=1;
		tiletable[cx+1][cy+1]=1;
		tiletable[dx+1][dy+1]=1;
		r=rr;g=gg;b=bb;
	}

	void Set(int l, int ax, int ay, int bx, int by, int cx, int cy, int dx, int dy, int rr, int gg, int bb){
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				tiletable[i][j]=0;
				}
			}
		lock=l;
		tiletable[ax+1][ay+1]=1;
		tiletable[bx+1][by+1]=1;
		tiletable[cx+1][cy+1]=1;
		tiletable[dx+1][dy+1]=1;
		r=rr;g=gg;b=bb;
	}

	void Draw(int x, int y){
		SDL_Rect offset;
		offset.w=30;
		offset.h=30;

		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(tiletable[i][j]){
						offset.x=x+250+(30*(i));
						offset.y=y+(30*(j));
						tile.Draw(x+250+(30*i), y+30*j, r, g, b);

						/*Replace the line above with Draw() method in CTile class*/
				}
			}}

	}

	void TryTurn(void){
		for(int i=0; i<4; i++){for(int j=0; j<4; j++){bufftiletable[i][j]=0;}}
		bufftiletable[1][1]=1;
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(tiletable[i][j]){
					if(i-1<0 && j-1<0){
					 bufftiletable[0][2]=1;
					}else
					if(i-1<0 && j-1>0){
					 bufftiletable[i+2][j]=1;
					}else
					if(i-1>0 && j-1>0){
					 bufftiletable[i][j-2]=1;
					}else
					if(i-1>0 && j-1<0){
					 bufftiletable[i-2][j]=1;
					}else
					if(i==0 && j==1){bufftiletable[1][2]=1;}else
					if(i==1 && j==2){bufftiletable[2][1]=1;}else
					if(i==2 && j==1){bufftiletable[1][0]=1;}else
					if(i==1 && j==0){bufftiletable[0][1]=1;}else
					if(i==3 && j==1){bufftiletable[1][3]=1;}else
					if(i==1 && j==3){bufftiletable[3][1]=1;}
				}
			}
		}
	}

	void Turn(void){
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
			tiletable[i][j]=bufftiletable[i][j];
			}
		}

	}

	bool GetTable(void){
		return tiletable;
	}

};

class CButton{
		private:
		bool active;
		int ir, ig, ib;
		int ar, ag, ab;
		int x, y;
		int w,h;
		const char* text;

		public:
		CButton(int xx, int yy, int width, int height, int ired, int igreen, int iblue, int ared, int agreen, int ablue, int aactive, const char *label){
			x=xx;y=yy;
			w=width;h=height;
			ir=ired;ig=igreen;ib=iblue;
			ar=ared;ag=agreen;ab=ablue;
			text=label;
			active=aactive;
		}

		bool Active(void){
			return active;
			}

		void ChangeActivity(void){
				active=!active;
		}

		void Draw(void){
			if(active){
				RBC_DrawRect(x-1, y-1, w+2, h+2, 255, 255, 255);
				RBC_DrawRect(x, y, w, h, ar, ag, ab);
			}else{
				RBC_DrawRect(x, y, w, h, ir, ig, ib);
				}
			RBC_Write(x+10, y+h/4, text, screen);
		}
};

SDL_Surface* RBC_LoadBMP(const char* name){
	SDL_Surface* loadedimg=SDL_LoadBMP(name);
	return SDL_DisplayFormat(loadedimg);
}

void RBC_BlitSurface(int x, int y, SDL_Surface *src, SDL_Surface *dest){
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;

	SDL_BlitSurface(src, NULL, dest, &offset);
}/*Method of loading bitmap with easy calling*/

void RBC_Write(int x, int y, const char* text, SDL_Surface *dest){
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;
	SDL_Surface *buff=TTF_RenderText_Solid(font, text, textColor);
	SDL_BlitSurface(buff, NULL, dest, &offset);
}/*Method of writing text in const char format on the screen. It uses global font*/

void RBC_Write(int x, int y, int number, SDL_Surface *dest){
	char textbuffer[100];
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;
	SDL_Surface *buff=TTF_RenderText_Solid(font, itoa(number, textbuffer, 10), textColor);
	SDL_BlitSurface(buff, NULL, dest, &offset);
}/*Overloaded version of function for writing numbers on the screen*/

void RBC_DrawRect(int x, int y, int w, int h, int r, int g, int b){
	SDL_Rect offset;
	offset.x=x;
	offset.y=y;
	offset.w=w;
	offset.h=h;
	SDL_FillRect(screen, &offset, SDL_MapRGB(screen->format, r, g, b));
}

int FPSStart=0;
int FPSFinish=0;
int LastSec=0;
int LastFPS=FPSRATE;
int LastFrame;

int GetFPS(void){
	if((SDL_GetTicks()/1000)-LastSec){
		LastSec=SDL_GetTicks()/1000;
		LastFPS=FPSFinish-FPSStart;
		FPSStart=frame;
	}else{
		FPSFinish=frame;
	}
	return LastFPS;
}/*A method which shows frames count in last second.*/

void SetFPS(void){
	if(SDL_GetTicks()-LastFrame<=(1000/FPSRATE)){SDL_Delay((1000/FPSRATE)-(SDL_GetTicks()-LastFrame));}
}/*Function which locks frames per second according to FPSRATE definition*/

class CGameManager{
	private:
	int speed;
	int done;
	int LastAction;
	bool warning;
	CTile* GameTable[10][20];

	bool blocktable;

	int gameblockx;
	int gameblocky;

	public:

	CGameManager(void){
			for(int i=0, j=0; i<10; i++){for(j=0;j<20;j++){GameTable[i][j]=NULL;}}

			//for(int i=0; i<10; i++){
			//GameTable[8][i]=new CTile;
			//GameTable[8][i]->Set(250+30*8, 30*i);}
			done=0;
			LastAction=0;
			speed=2;
			gameblockx=2;
			gameblocky=0;
	}

	int ReturnSpeed(void){return speed;}
	int ReturnDone(void){return done;}

	void MoveBlockLeft(CBlock* block){
			bool collision=0;

			for(int i=3; i>=0 && !collision; i--){
				for(int j=0; j<4 && !collision; j++){
					if(block->tiletable[i][j]){
							if(GameTable[i+gameblockx-1][j+gameblocky]){collision=1;}
					}
				}
			}

			if(gameblockx<=0){
			for(int i=0; i<4; i++){
					if(block->tiletable[0-gameblockx][i]){collision=1;}
			}
			}
			if(!collision){--gameblockx;warning=0;}
	}

	void MoveBlockRight(CBlock* block){
			bool collision=0;

			for(int i=3; i>=0 && !collision; i--){
				for(int j=0; j<4 && !collision; j++){
					if(block->tiletable[i][j]){
							if(GameTable[i+gameblockx+1][j+gameblocky]){collision=1;}
					}
				}
			}

			if(gameblockx>=6){
			for(int i=0; i<4; i++){
					if(block->tiletable[10-gameblockx-1][i]){collision=1;}
			}
			}
			if(!collision){++gameblockx;warning=0;}
	}

	int GetGameBlockX(void){
			return gameblockx;
	}

	int GetGameBlockY(void){
			return gameblocky;
	}

	void SpeedUp(void){speed=speed+2;}

	void TurnGameBlock(CBlock* block){
		block->TryTurn();
		bool collision=0;

		if(gameblockx>6){ //from right
			for(int i=0; i<4; i++){
					if(block->bufftiletable[10-gameblockx][i]){collision=1;}
			}
		}

		if(gameblockx<0){ //from left
			for(int i=0; i<4; i++){
					if(block->bufftiletable[-gameblockx][i]){collision=1;}
			}
		}

		if(gameblocky>15){ /*it is case when table of block reaches the end of the board*/
			for(int i=0; i<4; i++){
					if(block->bufftiletable[i][20-gameblocky]){collision=1;}
			}
			}

		for(int i=0; i<4 && !collision; i++){
			for(int j=0; j<4 && !collision; j++){
				if(block->bufftiletable[i][j]){
					if(GameTable[i+gameblockx][j+gameblocky]){
						collision=1;
					}
				}
			}
		}

		if(!collision){block->Turn();warning=0;}
	}

	void PurgeVerse(int number){

			for(int i=number-1; i>0; i--){
					for(int j=0; j<10; j++){
						//if(GameTable[j][i]==NULL){GameTable[j][i+1]=NULL;}else{
						GameTable[j][i+1]=GameTable[j][i];//}
					}
			}
	}

	void CheckTable(void){
		int counter=0;
		for(int i=19, j; i>=0 && counter!=11; i--){
			counter=0;
			for(j=0; j<10; j++){
				if(GameTable[j][i]){counter++;}
			}
			if(counter==10){PurgeVerse(i);i++;done++;}
			else if(!counter){counter=11;}
		}
	}

	void Refresh(CBlock* block, CBlock* next){
		int tiem=SDL_GetTicks();
		if(!(done%25) && done!=0){SpeedUp();done++;}
		if(tiem-LastAction>1000/speed){
			if(!warning){
			LastAction=tiem;

			bool collision=0;

			/*Hypothetical collision with other tile*/
			for(int i=0; i<4 && !collision; i++){
				for(int j=3; j>=0 && !collision; j--){
					if(block->tiletable[i][j]){
							if(GameTable[i+gameblockx][j+gameblocky+1]){collision=1;}
					}
				}
			}


			if(gameblocky>15){ /*it is case when table of block reaches the end of the board*/
			for(int i=0; i<4; i++){
					if(block->tiletable[i][19-gameblocky]){collision=1;}
			}
			}
			if(!collision){++gameblocky;}else{warning=1;}
		//block->tiletable[0][0]
			}else{
				for(int i=0; i<4; i++){
					for(int j=0; j<4; j++){
						if(block->tiletable[i][j]){
							GameTable[i+gameblockx][j+gameblocky]=new CTile;
							GameTable[i+gameblockx][j+gameblocky]->Set(250+30*(i+gameblockx), 30*(j+gameblocky));
						}
					}
				}
			gameblockx=3;
			gameblocky=-1;

			srand(time(NULL));

			*block=*next;

			switch(rand()%7){
					case 0: next->Set(0, -1, 0, 0, 0, 1, 0, 0, -1,179,206,221);break; //t
					case 1: next->Set(0, -1,-1,0,-1,0,0,1,0, 198,255,126);break; //z
					case 2: next->Set(0, -1,0,0,0,0,-1,1,-1, 126,196,255);break; //s
					case 3: next->Set(1, 0,0,1,0,0,1,1,1, 100, 100, 0);break; //o
					case 4: next->Set(0, 0,-1,0,0,0,1,0,2, 255,159,126);break; //i
					case 5: next->Set(0, -1,1,0,1,0,0,0,-1, 139,77,156);break; //j
					case 6: next->Set(0, 0,-1,0,0,0,1,1,1, 255,229,126);break; //l
			}

			warning=0;

			CheckTable();
			}
		}
	}

	void DrawTable(void){
			for(int i=0; i<10; i++){
				for(int j=0; j<20; j++){
					if(GameTable[i][j]!=NULL){
						GameTable[i][j]->Set(250+i*30, j*30);
						GameTable[i][j]->Draw(250+i*30, j*30, 0);
						}
				}
			}
	}
};

int main ( int argc, char** argv )
{

    if ( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "Unable to init SDL: %s\n", SDL_GetError() );
        return 1;
    }

     atexit(SDL_Quit);

     screen = SDL_SetVideoMode(SCREENW, SCREENH, 32,
                                           SDL_HWSURFACE|SDL_DOUBLEBUF);
    if ( !screen )
    {
        printf("Unable to set 800x600 video: %s\n", SDL_GetError());
        return 1;
    }
	SDL_WM_SetCaption("Szit the Game", NULL);
	if( TTF_Init() == -1 )
    {
		printf("Unable to initialize font");
        return 1;
    }

    font=TTF_OpenFont("lazy.ttf", 28);

    // centre the bitmap on screen

	CGameManager manager;

    bool done = false;
    CBlock blockT(0, -1, 0, 0, 0, 1, 0, 0, -1, 100, 100, 100); //t
    blockT.TryTurn();
    blockT.Turn();
    blockT.TryTurn();
    blockT.Turn();

    CBlock blockZ(0, -1,-1,0,-1,0,0,1,0, 198,255,126); //z
    CBlock blockS(0, -1,0,0,0,0,-1,1,-1, 126,196,255); //s
    CBlock blockO(1, 0,0,1,0,0,1,1,1, 100, 100, 0); //o
    CBlock blockI(0, 0,-1,0,0,0,1,0,2, 255,159,126); //i
    CBlock blockJ(0, -1,1,0,1,0,0,0,-1, 139,77,156); //j
    CBlock blockL(0, 0,-1,0,0,0,1,1,1, 255,229,126); //l

    CBlock GameBlock(0, -1, 0, 0, 0, 1, 0, 0, -1, 179,206,221); //creating t
    CBlock NextBlock(0, -1, 0, 0, 0, 1, 0, 0, -1, 179,206,221); //t
    //CBlock GameBlock(0, -1,0,0,0,0,-1,1,-1); //s
    //CBlock GameBlock(0, 0,-1,0,0,0,1,0,2); //i


	CButton start(300, 400, 200, 50, 100, 100, 100, 150, 150, 150, 1, "Start");
	CButton exit(300, 475, 200, 50, 100, 100, 100, 150, 150, 150, 0, "Exit");
	manager.Refresh(&GameBlock, &NextBlock);
	manager.Refresh(&GameBlock, &NextBlock);
    // program main loop
    while (!done)
    {
        // message processing loop
        SDL_Event event;
        ++frame;
		SetFPS();
		LastFrame=SDL_GetTicks();

		if(gamestatus==1){manager.Refresh(&GameBlock, &NextBlock);
		}

        while (SDL_PollEvent(&event))
        {
            // check for messages
            switch (event.type)
            {
                // exit if the window is closed
            case SDL_QUIT:
                done = true;
                break;

                // check for keypresses
            case SDL_KEYDOWN:
                {
                    // exit if ESCAPE is pressed
                    if (event.key.keysym.sym == SDLK_ESCAPE)
                        {done = true;}

					if(!gamestatus)
					{
						if(event.key.keysym.sym == SDLK_DOWN || event.key.keysym.sym == SDLK_UP){
							start.ChangeActivity();
							exit.ChangeActivity();
						}
						if(event.key.keysym.sym == SDLK_RETURN){
							if(start.Active()){gamestatus=1;}
							else if(exit.Active()){done=1;}
						}
					}else
					if(gamestatus==1){
						if(event.key.keysym.sym == SDLK_SPACE){
								manager.TurnGameBlock(&GameBlock);
						}
						if(event.key.keysym.sym == SDLK_LEFT){
								manager.MoveBlockLeft(&GameBlock);
						}
						if(event.key.keysym.sym == SDLK_RIGHT){
								manager.MoveBlockRight(&GameBlock);
						}
						if(event.key.keysym.sym == SDLK_w){
								manager.SpeedUp();
						}
					}
                    break;
                }
            } // end switch
         }// end of message processing

        // DRAWING STARTS HERE


        // clear screen
        SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, 0, 0, 0));

        // draw bitmap




		if(gamestatus==0){
			int a=SDL_GetTicks();
			RBC_DrawRect(0, 0, screen->w, screen->h, 0, 0, 50);
			blockS.Draw(-100, 90+sin(a/100)*50);
			blockZ.Draw(50, 90+sin(a/100+10)*50);
			blockI.Draw(200, 90+sin(a/100+20)*50);
			blockT.Draw(350, 90+sin(a/100+30)*50);

			start.Draw();
			exit.Draw();
		}else
		if(gamestatus==1){
			switch(manager.ReturnSpeed()){
					case 2:RBC_DrawRect(0, 0, screen->w, screen->h, 105,210,231);break;
					case 4:RBC_DrawRect(0, 0, screen->w, screen->h, 167,219,216);break;
					case 6:RBC_DrawRect(0, 0, screen->w, screen->h, 224,228,204);break;
					case 8:RBC_DrawRect(0, 0, screen->w, screen->h, 243,134,48);break;
					case 10:RBC_DrawRect(0, 0, screen->w, screen->h, 250,105,0);break;
					case 12:RBC_DrawRect(0, 0, screen->w, screen->h, 250,70,0);break;
					case 14:RBC_DrawRect(0, 0, screen->w, screen->h, 250,35,0);break;

			}
			RBC_DrawRect(245, 0, 310, 600, 0,0,0);
			RBC_DrawRect(250, 0, 300, 600, 85,98,112);
			RBC_DrawRect(575, 75, 200, 200, 200, 200, 200);
			GameBlock.Draw(manager.GetGameBlockX()*30, manager.GetGameBlockY()*30);
			NextBlock.Draw(375, 150);
			manager.DrawTable();
			RBC_Write(575, 300, "Speed:", screen);
			RBC_Write(675, 300, manager.ReturnSpeed(), screen);
			RBC_Write(575, 330, "Score:", screen);
			RBC_Write(675, 330, manager.ReturnDone(), screen);

		}

        RBC_Write(0, 20, "FPS: ", screen);RBC_Write(50, 20, GetFPS(), screen);

        // DRAWING ENDS HERE

        // finally, update the screen :)
        SDL_Flip(screen);
    } // end main loop

    // free loaded bitmap
	TTF_CloseFont(font);
	TTF_Quit();
    // all is well ;)
    printf("Exited cleanly\n");
    return 0;
}
