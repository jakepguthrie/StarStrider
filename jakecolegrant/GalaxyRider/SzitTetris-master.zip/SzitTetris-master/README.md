szit_tetris
===========

Super-Zazzy Implementation of Tetris is first game I've ever written. 
Implemented with C++ and SDL library.
1. How to set up Code::Blocks? http://www.noquarterarcade.com/setting-up-a-codeblocks-project-with-sdl-on-windows

